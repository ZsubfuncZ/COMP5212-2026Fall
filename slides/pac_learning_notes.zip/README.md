# PAC Learning Lecture Notes

This package contains self-contained lecture notes based on the supplied COMP5212 lecture slides on PAC learning, VC dimension, and Rademacher complexity.

## Build

```bash
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
```

The source is `main.tex`; `references.bib` records standard references used for further reading.
